# Conventional Commits Reference Guide

This reference document outlines the standard commit prefixes (verbs) used to structure project history, automate semantic versioning, and generate clean changelogs.

## Core Structural Format
```text
<type>(<optional scope>): <description>

[optional body]

[optional footer(s)]
```

---

## Commit Prefix Reference Table

| Prefix | Category | Purpose & Explanation |
| :--- | :--- | :--- |
| **`feat`** | Production | **Features:** Used when adding a completely new feature or capability to the application. Directly correlates to a `MINOR` semantic version bump. |
| **`fix`** | Production | **Bug Fixes:** Used when correcting a bug, error, or unintended behavior in the production codebase. Directly correlates to a `PATCH` semantic version bump. |
| **`docs`** | Auxiliary | **Documentation:** Used for any changes exclusively related to documentation. This includes files like `README.md`, internal wikis, or inline code comments. |
| **`refactor`** | Structural | **Code Refactoring:** Used for a code change that neither fixes a bug nor adds a feature. Examples include optimizing logic structure, renaming variables, or cleaning up messy code paths without altering external behavior. |
| **`perf`** | Performance | **Performance Improvements:** A specialized type of refactor dedicated exclusively to code changes that explicitly improve runtime speed, memory footprint, or execution efficiency. |
| **`style`** | Formatting | **Code Formatting:** Used for changes that do not affect the execution meaning of the code. This covers whitespace adjustments, missing semicolons, indentation formatting, and code linting fixes. |
| **`test`** | Quality | **Testing:** Used when adding missing automated tests, correcting existing tests, or updating test configurations (e.g., Unit tests, Integration tests, Cypress/Playwright scripts). |
| **`build`** | DevOps | **Build Configuration:** Used for modifications that impact the compilation or build system, or changes to external package dependencies (e.g., updating a `package.json`, configuring Webpack/Vite, modifying Maven/Gradle scripts). |
| **`ci`** | DevOps | **Continuous Integration:** Used for updating or creating automation pipelines, deployment configurations, and workflow scripts (e.g., GitHub Actions workflows, GitLab CI, CircleCI configs). |
| **`chore`** | Maintenance| **Routine Tasks:** Used for general housekeeping tasks that do not modify production code or test files. Examples include updating `.gitignore`, license text modifications, or setting up project meta-files. |
| **`revert`** | History | **Reversions:** Used explicitly when undoing a previous commit. The commit title should reference the reverted commit, and the body should include its SHA. |

---

## Writing Guidelines

1. **Imperative Mood:** Always write the summary description in the imperative, present-tense mood (e.g., use `feat: add logging` instead of `feat: added logging` or `feat: adds logging`).
2. **Breaking Changes:** If a change breaks backward compatibility, append an exclamation mark `!` directly after the type/scope (e.g., `feat(api)!: drop support for v1 endpoints`) or include `BREAKING CHANGE:` at the beginning of the footer.
3. **Keep it Concise:** Limit the first summary line to 50 characters or less whenever possible.
